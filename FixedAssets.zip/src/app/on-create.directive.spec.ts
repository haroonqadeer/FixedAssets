import { OnCreateDirective } from './on-create.directive';

describe('OnCreateDirective', () => {
  it('should create an instance', () => {
    const directive = new OnCreateDirective();
    expect(directive).toBeTruthy();
  });
});
