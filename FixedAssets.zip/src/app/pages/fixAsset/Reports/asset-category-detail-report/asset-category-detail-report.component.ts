import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-asset-category-detail-report',
  templateUrl: './asset-category-detail-report.component.html',
  styleUrls: ['./asset-category-detail-report.component.scss']
})
export class AssetCategoryDetailReportComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
