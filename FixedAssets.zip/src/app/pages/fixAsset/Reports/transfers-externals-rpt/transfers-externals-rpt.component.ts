import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-transfers-externals-rpt',
  templateUrl: './transfers-externals-rpt.component.html',
  styleUrls: ['./transfers-externals-rpt.component.scss']
})
export class TransfersExternalsRptComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
